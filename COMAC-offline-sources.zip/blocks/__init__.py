# Blocks module - UI components
